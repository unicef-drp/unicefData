#!/usr/bin/env python3
"""
Test enrichment pipeline using fixture data (partial update).

This script validates the metadata enrichment pipeline end-to-end using
frozen serieskeysonly XML fixtures for 5 representative dataflows:

  CME, ECD, EDUCATION, HIV_AIDS, IMMUNISATION

It exercises the same logic as the production scripts:
  1. build_indicator_dataflow_map.py  (indicator -> dataflow mapping)
  2. build_dataflow_metadata.py       (dimension extraction)
  3. enrich_stata_metadata_complete.py (tier + disaggregation enrichment)

The test is deliberately partial (5 of ~69 dataflows) to keep fixture
size manageable while still proving the pipeline works.

Usage:
    python test_enrichment_pipeline.py [--verbose]

Exit codes:
    0 = all assertions pass
    1 = one or more assertions failed

Author: JP Azevedo / Claude Code
Date: 2026-02-10
"""

import os
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
FIXTURES_DIR = Path(__file__).parent
SERIESKEYS_DIR = FIXTURES_DIR / "serieskeys"

# The 5 representative dataflows stored as fixtures
FIXTURE_DATAFLOWS = {
    "CME":           {"version": "1.0", "min_indicators": 20},
    "ECD":           {"version": "1.0", "min_indicators": 5},
    "EDUCATION":     {"version": "1.0", "min_indicators": 10},
    "HIV_AIDS":      {"version": "1.0", "min_indicators": 10},
    "IMMUNISATION":  {"version": "1.0", "min_indicators": 5},
}

# Expected disaggregation dimensions per dataflow (from the paper's Table 1)
EXPECTED_DIMENSIONS = {
    "CME":          {"must_have": ["SEX", "WEALTH_QUINTILE", "REF_AREA", "INDICATOR"]},
    "ECD":          {"must_have": ["SEX", "AGE", "WEALTH_QUINTILE", "RESIDENCE", "REF_AREA", "INDICATOR"]},
    "EDUCATION":    {"must_have": ["SEX", "WEALTH_QUINTILE", "RESIDENCE", "REF_AREA", "INDICATOR"]},
    "HIV_AIDS":     {"must_have": ["SEX", "AGE", "WEALTH_QUINTILE", "RESIDENCE", "REF_AREA", "INDICATOR"]},
    "IMMUNISATION": {"must_have": ["AGE", "REF_AREA", "INDICATOR"]},
}

# Indicators we know exist in these dataflows (from DET fixtures)
KNOWN_INDICATORS = {
    "CME_MRY0T4":  "CME",        # Under-5 mortality (DET-01 to DET-10)
    "CME_MRM0":    "CME",        # Neonatal mortality (DET-07)
    "IM_MCV1":     "IMMUNISATION",  # MCV1 vaccination (DET-11)
}


# ---------------------------------------------------------------------------
# Stage 1: Parse serieskeysonly XML -> extract indicator-to-dataflow mapping
# ---------------------------------------------------------------------------
def parse_serieskeys_xml(xml_path):
    """
    Parse a serieskeysonly XML file and extract dimensions.
    Mirrors the logic in build_dataflow_metadata.py lines 139-167.
    """
    tree = ET.parse(xml_path)
    root = tree.getroot()

    dimensions = defaultdict(set)

    # Iterate over all Series elements (handle various namespace patterns)
    for series in root.iter():
        if series.tag.endswith("Series") or series.tag == "Series":
            for attr_name, attr_value in series.attrib.items():
                if attr_name in ("DATAFLOW", "OBS_VALUE", "TIME_PERIOD"):
                    continue
                dimensions[attr_name].add(attr_value)

    return {dim: sorted(values) for dim, values in dimensions.items()}


def build_partial_mapping(all_dimensions):
    """
    Build indicator-to-dataflow mapping from parsed dimensions.
    Mirrors the logic in build_indicator_dataflow_map.py lines 128-148.
    """
    indicator_to_dataflows = defaultdict(list)

    for dataflow_id, dims in all_dimensions.items():
        indicators = dims.get("INDICATOR", [])
        for ind in indicators:
            indicator_to_dataflows[ind].append(dataflow_id)

    return dict(indicator_to_dataflows)


# ---------------------------------------------------------------------------
# Stage 2: Enrichment (tier + disaggregations)
# ---------------------------------------------------------------------------
def classify_tier(has_metadata, has_data):
    """Mirrors enrich_stata_metadata_complete.py lines 71-96."""
    if has_metadata and has_data:
        return (1, "metadata_and_data")
    elif has_metadata and not has_data:
        return (2, "metadata_only_no_data")
    elif not has_metadata and has_data:
        return (3, "data_only_no_metadata")
    return (None, "invalid_state")


def enrich_indicators(indicator_to_dataflows, all_dimensions):
    """
    Simulate the enrichment pipeline for the fixture subset.
    Returns summary statistics for validation.
    """
    enriched = {}

    for indicator_code, dataflows in indicator_to_dataflows.items():
        # Sort: GLOBAL_DATAFLOW always last
        other = sorted(df for df in dataflows if df != "GLOBAL_DATAFLOW")
        if "GLOBAL_DATAFLOW" in dataflows:
            other.append("GLOBAL_DATAFLOW")
        sorted_dfs = other

        # Tier classification (all indicators in dataflows have data)
        tier, reason = classify_tier(has_metadata=True, has_data=True)

        # Disaggregations from primary dataflow
        primary_df = sorted_dfs[0]
        dims = all_dimensions.get(primary_df, {})
        disaggregations = []
        disaggregations_with_totals = []

        for dim_name in sorted(dims.keys()):
            if dim_name == "INDICATOR":
                continue
            disaggregations.append(dim_name)
            if "_T" in dims[dim_name]:
                disaggregations_with_totals.append(dim_name)

        enriched[indicator_code] = {
            "dataflows": sorted_dfs if len(sorted_dfs) > 1 else sorted_dfs[0],
            "tier": tier,
            "tier_reason": reason,
            "disaggregations": disaggregations,
            "disaggregations_with_totals": disaggregations_with_totals,
        }

    return enriched


# ---------------------------------------------------------------------------
# Assertions
# ---------------------------------------------------------------------------
class TestResults:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []

    def ok(self, msg, verbose=False):
        self.passed += 1
        if verbose:
            print(f"  PASS: {msg}")

    def fail(self, msg, verbose=True):
        self.failed += 1
        self.errors.append(msg)
        if verbose:
            print(f"  FAIL: {msg}")


# ---------------------------------------------------------------------------
# Main test runner
# ---------------------------------------------------------------------------
def run_tests(verbose=False):
    results = TestResults()

    print("=" * 70)
    print("ENRICHMENT PIPELINE TEST (partial, 5 dataflows)")
    print("=" * 70)

    # ------------------------------------------------------------------
    # Phase 1: Parse fixture XML files
    # ------------------------------------------------------------------
    print("\n[Phase 1] Parsing serieskeysonly XML fixtures...")

    all_dimensions = {}
    for df_id, spec in FIXTURE_DATAFLOWS.items():
        xml_path = SERIESKEYS_DIR / f"{df_id}.xml"

        # Assert fixture file exists
        if not xml_path.exists():
            results.fail(f"Fixture missing: {xml_path}")
            continue

        dims = parse_serieskeys_xml(xml_path)

        # Assert we extracted some dimensions
        if len(dims) == 0:
            results.fail(f"{df_id}: no dimensions extracted from XML")
            continue
        results.ok(f"{df_id}: {len(dims)} dimensions extracted", verbose)

        # Assert minimum indicator count
        ind_count = len(dims.get("INDICATOR", []))
        if ind_count < spec["min_indicators"]:
            results.fail(
                f"{df_id}: expected >= {spec['min_indicators']} indicators, got {ind_count}"
            )
        else:
            results.ok(f"{df_id}: {ind_count} indicators (>= {spec['min_indicators']})", verbose)

        # Assert expected dimensions present
        expected = EXPECTED_DIMENSIONS.get(df_id, {}).get("must_have", [])
        for dim in expected:
            if dim in dims:
                results.ok(f"{df_id}: dimension {dim} present", verbose)
            else:
                results.fail(f"{df_id}: expected dimension {dim} missing (got: {list(dims.keys())})")

        all_dimensions[df_id] = dims

    print(f"  Parsed {len(all_dimensions)} dataflows")

    # ------------------------------------------------------------------
    # Phase 2: Build indicator-to-dataflow mapping
    # ------------------------------------------------------------------
    print("\n[Phase 2] Building indicator-to-dataflow mapping...")

    indicator_to_dfs = build_partial_mapping(all_dimensions)
    total_indicators = len(indicator_to_dfs)
    multi_df = sum(1 for dfs in indicator_to_dfs.values() if len(dfs) > 1)

    print(f"  Unique indicators: {total_indicators}")
    print(f"  In multiple dataflows: {multi_df}")

    # Assert we found a reasonable number of indicators
    if total_indicators < 50:
        results.fail(f"Expected >= 50 unique indicators across 5 dataflows, got {total_indicators}")
    else:
        results.ok(f"{total_indicators} unique indicators (>= 50)", verbose)

    # Assert known indicators map to correct dataflows
    for ind_code, expected_df in KNOWN_INDICATORS.items():
        if ind_code in indicator_to_dfs:
            if expected_df in indicator_to_dfs[ind_code]:
                results.ok(f"{ind_code} -> {expected_df}", verbose)
            else:
                results.fail(
                    f"{ind_code}: expected in {expected_df}, found in {indicator_to_dfs[ind_code]}"
                )
        else:
            results.fail(f"{ind_code}: not found in any fixture dataflow")

    # ------------------------------------------------------------------
    # Phase 3: Run enrichment
    # ------------------------------------------------------------------
    print("\n[Phase 3] Running enrichment pipeline...")

    enriched = enrich_indicators(indicator_to_dfs, all_dimensions)

    # Assert all indicators were enriched
    if len(enriched) != total_indicators:
        results.fail(f"Enriched {len(enriched)} but expected {total_indicators}")
    else:
        results.ok(f"All {len(enriched)} indicators enriched", verbose)

    # Assert tier classification
    tier_counts = defaultdict(int)
    for data in enriched.values():
        tier_counts[data["tier"]] += 1

    # All fixture indicators should be tier 1 (they have both metadata and data)
    if tier_counts[1] == len(enriched):
        results.ok(f"All {tier_counts[1]} indicators classified as tier 1", verbose)
    else:
        results.fail(f"Expected all tier 1, got: {dict(tier_counts)}")

    # Assert disaggregations populated
    with_disagg = sum(1 for d in enriched.values() if d["disaggregations"])
    if with_disagg == len(enriched):
        results.ok(f"All {with_disagg} indicators have disaggregations", verbose)
    else:
        results.fail(f"Only {with_disagg}/{len(enriched)} have disaggregations")

    # Assert specific known indicator enrichment
    if "CME_MRY0T4" in enriched:
        cme = enriched["CME_MRY0T4"]
        # CME should have SEX disaggregation
        if "SEX" in cme["disaggregations"]:
            results.ok("CME_MRY0T4 has SEX disaggregation", verbose)
        else:
            results.fail(f"CME_MRY0T4 missing SEX disaggregation: {cme['disaggregations']}")
        # CME should have SEX with _T total
        if "SEX" in cme["disaggregations_with_totals"]:
            results.ok("CME_MRY0T4: SEX has _T total", verbose)
        else:
            results.fail(f"CME_MRY0T4: SEX missing _T total: {cme['disaggregations_with_totals']}")

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    print("\n" + "=" * 70)
    print(f"RESULTS: {results.passed} passed, {results.failed} failed")
    print("=" * 70)

    if results.errors:
        print("\nFailures:")
        for err in results.errors:
            print(f"  - {err}")
        return 1
    else:
        print("\nAll assertions passed. Enrichment pipeline validated.")
        return 0


if __name__ == "__main__":
    verbose = "--verbose" in sys.argv or "-v" in sys.argv
    sys.exit(run_tests(verbose))
