# API Metadata Fixtures (Raw SDMX XML)

Frozen snapshots of the raw SDMX XML responses downloaded from the UNICEF
Data Warehouse API. These are the **upstream source data** from which the
YAML metadata files (`_unicefdata_*.yaml`) are derived.

## Provenance chain

```
Layer 0: SDMX API (XML)
   [this dir]
        |
        v
Layer 1: unicefdata_xmltoyaml  -->  _unicefdata_*.yaml  (simple 1:1 derivations)
                                     [derived YAML in src/_/]

Layer 1b: build_indicator_dataflow_map.py    -->  _indicator_dataflow_map.yaml
          build_dataflow_metadata.py         -->  _unicefdata_dataflow_metadata.yaml
          (query ~69 dataflows via /data/ endpoint, serieskeysonly)
          [frozen snapshots in enrichment/ subdir]
                      |
                      v
Layer 2: enrich_stata_metadata_complete.py
          inputs: _unicefdata_indicators.yaml (from Layer 1)
                + _indicator_dataflow_map.yaml (from Layer 1b)
                + _unicefdata_dataflow_metadata.yaml (from Layer 1b)
                      |
                      v
         _unicefdata_indicators_metadata.yaml  (enriched: tiers, dataflows, disaggregations)
```

## Files

### Dataflow catalog

| File | API endpoint | Derives |
|------|-------------|---------|
| `dataflows.xml` | `/dataflow/UNICEF?references=none&detail=full` | `_unicefdata_dataflows.yaml` |
| `dataflow_CME_dsd.xml` | `/dataflow/UNICEF/CME/1.0?references=all` | `_dataflows/CME.yaml`, `_dataflow_index.yaml` |

### Codelists (dimension values)

| File | API endpoint | Derives |
|------|-------------|---------|
| `codelist_CL_UNICEF_INDICATOR.xml` | `/codelist/UNICEF/CL_UNICEF_INDICATOR/latest` | `_unicefdata_indicators.yaml` |
| `codelist_CL_COUNTRY.xml` | `/codelist/UNICEF/CL_COUNTRY/latest` | `_unicefdata_countries.yaml` |
| `codelist_CL_WORLD_REGIONS.xml` | `/codelist/UNICEF/CL_WORLD_REGIONS/latest` | `_unicefdata_regions.yaml` |
| `codelist_CL_AGE.xml` | `/codelist/UNICEF/CL_AGE/latest` | `_unicefdata_codelists.yaml` (CL_AGE section) |
| `codelist_CL_WEALTH_QUINTILE.xml` | `/codelist/UNICEF/CL_WEALTH_QUINTILE/latest` | `_unicefdata_codelists.yaml` (CL_WEALTH_QUINTILE) |
| `codelist_CL_RESIDENCE.xml` | `/codelist/UNICEF/CL_RESIDENCE/latest` | `_unicefdata_codelists.yaml` (CL_RESIDENCE) |
| `codelist_CL_UNIT_MEASURE.xml` | `/codelist/UNICEF/CL_UNIT_MEASURE/latest` | `_unicefdata_codelists.yaml` (CL_UNIT_MEASURE) |
| `codelist_CL_OBS_STATUS.xml` | `/codelist/UNICEF/CL_OBS_STATUS/latest` | `_unicefdata_codelists.yaml` (CL_OBS_STATUS) |

### Enrichment intermediates (Layer 1b)

Stages 1-2 of the enrichment pipeline each query all ~69 dataflows via
`/data/UNICEF,{dataflow},{version}/all?detail=serieskeysonly`. Storing 69+
raw XML responses would be impractical, so we freeze the **derived YAML
products** instead. These are the inputs to `enrich_stata_metadata_complete.py`
(Stage 3) which produces the final `_unicefdata_indicators_metadata.yaml`.

| File | Generator | Description |
|------|-----------|-------------|
| `enrichment/_indicator_dataflow_map.yaml` | `build_indicator_dataflow_map.py` | Indicator→dataflow mapping (753 indicators, 69 dataflows) |
| `enrichment/_unicefdata_dataflow_metadata.yaml` | `build_dataflow_metadata.py` | Dataflow dimension schemas (70 dataflows, all dimension values) |

**Why YAML snapshots instead of raw XML?**
Each intermediate file is built from ~69 individual `/data/` endpoint queries
(one per dataflow). Storing 69 XML responses (~50+ MB) would be excessive.
The YAML snapshots (70 KB + 414 KB) capture the same information compactly
and are the actual inputs to the enrichment step.

### Partial enrichment test (serieskeysonly XML)

Raw `/data/` serieskeysonly XML for 5 representative dataflows, used by
`test_enrichment_pipeline.py` to validate the enrichment pipeline end-to-end
without querying the live API. These cover 104 indicators across diverse
dimension combinations.

| File | Dataflow | Indicators | Key dimensions |
|------|----------|------------|----------------|
| `enrichment/serieskeys/CME.xml` | Child Mortality Estimates | 34 | SEX, WEALTH_QUINTILE |
| `enrichment/serieskeys/ECD.xml` | Early Childhood Development | 6 | SEX, AGE, WEALTH, RESIDENCE, MATERNAL_EDU |
| `enrichment/serieskeys/EDUCATION.xml` | Education | 21 | SEX, WEALTH_QUINTILE, RESIDENCE |
| `enrichment/serieskeys/HIV_AIDS.xml` | HIV/AIDS | 25 | SEX, AGE, WEALTH, RESIDENCE |
| `enrichment/serieskeys/IMMUNISATION.xml` | Immunisation | 18 | AGE |

Run the partial enrichment test:

```bash
cd stata/qa/fixtures/api/enrichment
python test_enrichment_pipeline.py --verbose
```

## Snapshot date

2026-02-10 (v2.2.0)

## Base URL

All endpoints are relative to:
`https://sdmx.data.unicef.org/ws/public/sdmxapi/rest`

## Regeneration

```bash
BASE=https://sdmx.data.unicef.org/ws/public/sdmxapi/rest
cd stata/qa/fixtures/api
curl -o dataflows.xml "$BASE/dataflow/UNICEF?references=none&detail=full"
curl -o codelist_CL_UNICEF_INDICATOR.xml "$BASE/codelist/UNICEF/CL_UNICEF_INDICATOR/latest"
curl -o codelist_CL_COUNTRY.xml "$BASE/codelist/UNICEF/CL_COUNTRY/latest"
curl -o codelist_CL_WORLD_REGIONS.xml "$BASE/codelist/UNICEF/CL_WORLD_REGIONS/latest"
curl -o codelist_CL_AGE.xml "$BASE/codelist/UNICEF/CL_AGE/latest"
curl -o codelist_CL_WEALTH_QUINTILE.xml "$BASE/codelist/UNICEF/CL_WEALTH_QUINTILE/latest"
curl -o codelist_CL_RESIDENCE.xml "$BASE/codelist/UNICEF/CL_RESIDENCE/latest"
curl -o codelist_CL_UNIT_MEASURE.xml "$BASE/codelist/UNICEF/CL_UNIT_MEASURE/latest"
curl -o codelist_CL_OBS_STATUS.xml "$BASE/codelist/UNICEF/CL_OBS_STATUS/latest"
curl -o dataflow_CME_dsd.xml "$BASE/dataflow/UNICEF/CME/1.0?references=all"

# Serieskeysonly XML for partial enrichment test
cd enrichment/serieskeys
for DF in CME ECD EDUCATION HIV_AIDS IMMUNISATION; do
  curl -o "${DF}.xml" "$BASE/data/UNICEF,${DF},1.0/all?format=sdmx-compact-2.1&detail=serieskeysonly"
done
```
