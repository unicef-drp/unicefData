# API Metadata Fixtures (Raw SDMX XML)

Frozen snapshots of the raw SDMX XML responses downloaded from the UNICEF
Data Warehouse API. These are the **upstream source data** from which the
YAML metadata files (`_unicefdata_*.yaml`) are derived.

## Provenance chain

```
SDMX API (XML)  -->  unicefdata_xmltoyaml  -->  _unicefdata_*.yaml
   [this dir]           [parsing step]          [derived YAML in src/_/]
                                                       |
                                                       v
                                             enrich_indicators_metadata.py
                                                       |
                                                       v
                                        _unicefdata_indicators_metadata.yaml
```

## Files

### Dataflow catalog

| File | API endpoint | Derives |
|------|-------------|---------|
| `dataflows.xml` | `/dataflow/UNICEF?references=none&detail=full` | `_unicefdata_dataflows.yaml` |
| `dataflow_CME_dsd.xml` | `/dataflow/UNICEF/CME/1.0?references=all` | `_dataflows/CME.yaml`, `_dataflow_index.yaml` |

### Codelists (dimension values)

| File | API endpoint | Derives |
|------|-------------|---------|
| `codelist_CL_UNICEF_INDICATOR.xml` | `/codelist/UNICEF/CL_UNICEF_INDICATOR/latest` | `_unicefdata_indicators.yaml` |
| `codelist_CL_COUNTRY.xml` | `/codelist/UNICEF/CL_COUNTRY/latest` | `_unicefdata_countries.yaml` |
| `codelist_CL_WORLD_REGIONS.xml` | `/codelist/UNICEF/CL_WORLD_REGIONS/latest` | `_unicefdata_regions.yaml` |
| `codelist_CL_AGE.xml` | `/codelist/UNICEF/CL_AGE/latest` | `_unicefdata_codelists.yaml` (CL_AGE section) |
| `codelist_CL_WEALTH_QUINTILE.xml` | `/codelist/UNICEF/CL_WEALTH_QUINTILE/latest` | `_unicefdata_codelists.yaml` (CL_WEALTH_QUINTILE) |
| `codelist_CL_RESIDENCE.xml` | `/codelist/UNICEF/CL_RESIDENCE/latest` | `_unicefdata_codelists.yaml` (CL_RESIDENCE) |
| `codelist_CL_UNIT_MEASURE.xml` | `/codelist/UNICEF/CL_UNIT_MEASURE/latest` | `_unicefdata_codelists.yaml` (CL_UNIT_MEASURE) |
| `codelist_CL_OBS_STATUS.xml` | `/codelist/UNICEF/CL_OBS_STATUS/latest` | `_unicefdata_codelists.yaml` (CL_OBS_STATUS) |

## Snapshot date

2026-02-10 (v2.2.0)

## Base URL

All endpoints are relative to:
`https://sdmx.data.unicef.org/ws/public/sdmxapi/rest`

## Regeneration

```bash
BASE=https://sdmx.data.unicef.org/ws/public/sdmxapi/rest
cd stata/qa/fixtures/api
curl -o dataflows.xml "$BASE/dataflow/UNICEF?references=none&detail=full"
curl -o codelist_CL_UNICEF_INDICATOR.xml "$BASE/codelist/UNICEF/CL_UNICEF_INDICATOR/latest"
curl -o codelist_CL_COUNTRY.xml "$BASE/codelist/UNICEF/CL_COUNTRY/latest"
curl -o codelist_CL_WORLD_REGIONS.xml "$BASE/codelist/UNICEF/CL_WORLD_REGIONS/latest"
curl -o codelist_CL_AGE.xml "$BASE/codelist/UNICEF/CL_AGE/latest"
curl -o codelist_CL_WEALTH_QUINTILE.xml "$BASE/codelist/UNICEF/CL_WEALTH_QUINTILE/latest"
curl -o codelist_CL_RESIDENCE.xml "$BASE/codelist/UNICEF/CL_RESIDENCE/latest"
curl -o codelist_CL_UNIT_MEASURE.xml "$BASE/codelist/UNICEF/CL_UNIT_MEASURE/latest"
curl -o codelist_CL_OBS_STATUS.xml "$BASE/codelist/UNICEF/CL_OBS_STATUS/latest"
curl -o dataflow_CME_dsd.xml "$BASE/dataflow/UNICEF/CME/1.0?references=all"
```
